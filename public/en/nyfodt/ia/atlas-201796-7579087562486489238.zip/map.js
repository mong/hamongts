{
	"template":"Single Map (HTML Edition)",
	"version":"6.7.4_b1,805 (2016-03-31 1512)",
	"boundingBox":"-118987.21800000001 6379392.870999999 1173869.5780000002 8013732.149",
	"layers":[
	{
		"type":"base-layer",
		"id":"_Nyfodt_4.shp1",
		"name":"Nyfodt_4.shp",
		"geometry":"polygon",
		"url":"_Nyfodt_4.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	}
	]
}