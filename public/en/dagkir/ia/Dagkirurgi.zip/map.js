{
	"template":"Single Map (HTML Edition)",
	"version":"6.7.1_b1,635 (2013-09-04 1449)",
	"boundingBox":"-136793.8005 6373968.9399999995 1174717.5105 8014549.86",
	"layers":[
	{
		"type":"base-layer",
		"id":"_HF_omr_3.shp1",
		"name":"Boområder HF",
		"geometry":"polygon",
		"url":"_HF_omr_3.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	}
	]
}